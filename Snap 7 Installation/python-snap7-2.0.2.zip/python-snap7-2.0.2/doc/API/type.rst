Types
=====

.. automodule:: snap7.type
   :members:
