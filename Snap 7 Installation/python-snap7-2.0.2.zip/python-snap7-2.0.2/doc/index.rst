.. python-snap7 documentation master file, created by
   sphinx-quickstart on Sat Nov  9 14:57:44 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to python-snap7's documentation!
========================================

Contents:

.. toctree::
   :maxdepth: 2

   introduction
   installation
   development

   API/client
   API/server
   API/partner
   API/logo
   API/type
   API/util



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
